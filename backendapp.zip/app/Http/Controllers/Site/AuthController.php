<?php 

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class AuthController extends Controller
{
	public function __construct()
	{

	}

	public function login(Request $request)
	{
		
	}
}